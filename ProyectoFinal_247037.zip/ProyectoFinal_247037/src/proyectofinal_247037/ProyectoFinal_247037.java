/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyectofinal_247037;
/**
 *
 * ESTE PROGRAMA FUE CREADO POR: Francisco de Jesús López Ruiz, el famosisimo Joshua Smith y el gran Oscarsinho Romansinho
 */
public class ProyectoFinal_247037 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
         
         Menu menu = new Menu();
         menu.mostrarMenuPrincipal();
    }
    
}