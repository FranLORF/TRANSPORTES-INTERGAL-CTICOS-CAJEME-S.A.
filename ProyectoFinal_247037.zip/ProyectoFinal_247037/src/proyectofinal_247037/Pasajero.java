/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectofinal_247037;

/**
 *
 * @author panchito
 */
public class Pasajero 
{
    private String nombre,id,destino;
    public Pasajero( ){}
    public Pasajero( String nombre,String id, String destino )
    {
        this.nombre=nombre;
        this.id=id;
        this.destino=destino;
    }
    public void setNombrePasajero( String nombre)
    {
        this.nombre=nombre;
    }
    public String getNombrePasajero( )
    {
        return nombre;
    }
    public void setIdentificacionPasajero( String id )
    {
        this.id=id;
    }
    public String getIdentificacionPasajero()
    {
        return id;
    }
    public void setDestinoPasajero( String destino )
    {
        this.destino=destino;
    }
    public String getDestinoPasajero()
    {
        if (destino==null) 
        {
            destino="TIC";
        }
        return destino;
    }
    public float obtenerCostoBoletoPasajero(String clase )
    {
        float costoBoleto=0;
        if (clase.equalsIgnoreCase("Ejecutiva") && destino.equalsIgnoreCase("Luna")) 
        {
            costoBoleto=3000;
            
        }
        if (clase.equalsIgnoreCase("Ejecutiva") && destino.equalsIgnoreCase("Europa")) 
        {
            costoBoleto=5250;
            
        }
        if (clase.equalsIgnoreCase("Ejecutiva") && destino.equalsIgnoreCase("Titan")) 
        {
           costoBoleto=10500;
           
        }
        if (clase.equalsIgnoreCase("Economica") && destino.equalsIgnoreCase("Luna")) 
        {
           costoBoleto=2000;
           
        }
        if (clase.equalsIgnoreCase("Economica") && destino.equalsIgnoreCase("Europa")) 
        {
           costoBoleto=3500;
           
        }
        if (clase.equalsIgnoreCase("Economica") && destino.equalsIgnoreCase("Titan")) 
        {
           costoBoleto=7000;
           
        }
        
        return costoBoleto;
    }

}
