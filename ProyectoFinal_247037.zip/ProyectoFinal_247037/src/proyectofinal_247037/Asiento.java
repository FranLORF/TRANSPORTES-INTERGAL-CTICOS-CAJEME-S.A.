/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectofinal_247037;

/**
 *
 * @author panchito
 */
public class Asiento 
{
    private int asiento;
    private String clase;
    private String ubicacion;
    private Pasajero pasajero;
    public Asiento( ) {}
    public Asiento(int asiento){
        this.asiento = asiento;
    }
    public Asiento( int asiento, String clase, String ubicacion )
    {
        this.asiento=asiento;
        this.clase=clase;
        this.ubicacion=ubicacion;
        pasajero=null;
    }
    public void setAsiento(int asiento)
    {
        this.asiento=asiento;
    }
    
    
    public int getAsiento(){
        return asiento;
    }
    
    
    public void setClase(String clase) 
    {
        this.clase = clase;
    }
    
    public String getClase() 
    {
        if (asiento>=1 && asiento<=4) 
        {
            clase="Ejecutiva";
        }
        if (asiento>=5 && asiento<=28) 
        {
            clase="Economica";
        }
        return clase;
    }

   public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    } 

    public String getUbicacion() 
    {
        return ubicacion;
    }
    
    
    
    public void setPasajero(Pasajero pasajero) {
        this.pasajero = pasajero;
    }
    
    
    public Pasajero getPasajero() 
    {
        if (pasajero==null) 
        {
            return pasajero;
        }
        return pasajero;
    }

    

    
    
}





