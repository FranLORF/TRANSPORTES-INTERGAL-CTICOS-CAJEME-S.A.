/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectofinal_247037;

/**
 *
 * @author panchito
 */
public class Nave 
{
    public Asiento ejecutivos[];
    public Asiento economicos[];
    public Nave()
    {
        ejecutivos = new Asiento[4];
        economicos = new Asiento[24];  
        for (int i=0; i<ejecutivos.length; i++){
            ejecutivos[i] = new Asiento(i+1);
        }
        
        for (int i=0; i<economicos.length; i++){
            economicos[i] = new Asiento(i+5);
        }
    }
    

}
