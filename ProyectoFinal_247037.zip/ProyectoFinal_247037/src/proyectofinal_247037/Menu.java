/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectofinal_247037;

import java.util.Scanner;

/**
 *
 * @author panchito
 */
public class Menu {

    private Nave nave;

    public Menu() {
        nave = new Nave();
    }

    public void mostrarMenuPrincipal() {

        Scanner lol = new Scanner(System.in);
        byte n = 0, sn;
        System.out.println("||       Listado de opciones               ||");
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("|| 1. Registro de reservaciones            ||");
        System.out.println("|| 2. Eliminacion de reservaciones         ||");
        System.out.println("|| 3. Modificacion de reservaciones        ||");
        System.out.println("|| 4. Submenu consulta de reservaciones    ||");
        System.out.println("|| 5. Mapa de ocupacion                    ||");
        System.out.println("|| 6. Reporte de reservaciones             ||");
        System.out.println("|| 7. Terminar                             ||");
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("|| Ingrese la opción que desea seleccionar ||");
        try {
            n = lol.nextByte();
        } catch (Exception e) {
        }
        switch (n) {
            case 1:
                registrarReservaciones();
                this.mostrarMenuPrincipal();
                break;
            case 2:
                eliminarReservaciones();
                this.mostrarMenuPrincipal();
                break;
            case 3:
                modificarReservaciones();
                this.mostrarMenuPrincipal();
                break;
            case 4:
                mostrarSubmenuConsultaReservaciones();
                this.mostrarMenuPrincipal();
                break;
            case 5:
                mostrarMapaOcupacion();
                this.mostrarMenuPrincipal();
                break;
            case 6:
                mostrarReporteReservaciones();
                this.mostrarMenuPrincipal();
                break;
            case 7:
                break;
            default:
                impError();
        }

    }

    public void registrarReservaciones() {
        Pasajero pasajero = new Pasajero();
        Asiento ob = new Asiento();
        mostrarMapaOcupacion();
        int asiento;
        float costoBoleto;
        String nombre, destino, clase, ubicacion, id;
        Scanner lol = new Scanner(System.in);
        System.out.println("|| INGRESE EL ASIENTO QUE DESEA EL PASAJERO ||");
        asiento = lol.nextInt();
        if (asiento == 0) {
            mostrarMenuPrincipal();
        }
        if (asiento < 1 && asiento > 28) {
            System.out.println("El número de asiento es invalido.");
            System.out.println("Favor de seleccionar uno entre 1-28");
            asiento = lol.nextInt();
        }
        if (asiento == 1
                || asiento == 5
                || asiento == 11
                || asiento == 17
                || asiento == 23
                || asiento == 4
                || asiento == 10
                || asiento == 16
                || asiento == 22
                || asiento == 28) {
            ubicacion = "Ventana";
            ob.setUbicacion(ubicacion);

        }
        if (asiento == 2
                || asiento == 3
                || asiento == 7
                || asiento == 8
                || asiento == 13
                || asiento == 14
                || asiento == 19
                || asiento == 20
                || asiento == 25
                || asiento == 26) {
            ubicacion = "Pasillo";
            ob.setUbicacion(ubicacion);

        }
        if (asiento == 6
                || asiento == 9
                || asiento == 12
                || asiento == 15
                || asiento == 18
                || asiento == 21
                || asiento == 24
                || asiento == 27) {
            ubicacion = "Centro";
            ob.setUbicacion(ubicacion);

        }

        for (Asiento asientoTemp : nave.ejecutivos) {
            if (asientoTemp.getAsiento() == asiento) {
                if (asientoTemp.getPasajero() == null) {

                    System.out.println("¿Se desea continuar con el Registro de Reservaciones, (S/N)?");
                    lol.nextLine();

                    String respuesta = lol.nextLine();

                    if (!respuesta.equalsIgnoreCase("S") && !respuesta.equalsIgnoreCase("N")) {
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        System.out.println("||        ALGO SALIO MAL                   ||");
                        System.out.println("||        LA RESPUESTA NO ES VÁLIDA        ||");
                        System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
                        System.out.println("||        Presione <Enter> para continuar  ||");
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        lol.nextLine();
                        lol.nextLine();
                        System.out.println("Ingrese una respuesta valida (S/N)");
                        respuesta = lol.nextLine();
                    }

                    if (respuesta.equalsIgnoreCase("N")) {
                        mostrarMenuPrincipal();
                    }
                    if (respuesta.equalsIgnoreCase("S")) {
                        System.out.println("Ingrese el nombre del Pasajero");
                        nombre = lol.nextLine();
                        for (int x = 0; x < nombre.length(); x++) {
                            char c = nombre.charAt(x);
                            // Si no está entre a y z, ni entre A y Z, ni es un espacio
                            if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == ' ')) {
                                System.out.println("ERROR, FAVOR DE INTRODUCIR UN NOMBRE VALIDO");
                                System.out.println("EL NOMBRE DEBE SER PARTE DEL ABECEDARIO |A-Z|");
                                nombre = lol.nextLine();

                            }
                        }

                        System.out.println("|| Ingrese el ID del Pasajero ||");
                        id = lol.nextLine();

                        System.out.println("|| Ingrese el Destino del Pasajero ||");

                        destino = lol.nextLine();

                        if (!destino.equalsIgnoreCase("Luna") && !destino.equalsIgnoreCase("Titan") && !destino.equalsIgnoreCase("Europa")) {
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                            System.out.println("||        ALGO SALIO MAL                   ||");
                            System.out.println("||        LA RESPUESTA NO ES VÁLIDA        ||");
                            System.out.println("||  FAVOR DE INGRESAR UNA OPCION VALIDA    ||");
                            System.out.println("||        Presione <Enter> para continuar  ||");
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                            destino = lol.nextLine();
                        }
                        ob.setAsiento(asiento);
                        clase = ob.getClase();
                        pasajero.setNombrePasajero(nombre);
                        pasajero.setIdentificacionPasajero(id);
                        pasajero.setDestinoPasajero(destino);
                        costoBoleto = pasajero.obtenerCostoBoletoPasajero(clase);
                        ubicacion = ob.getUbicacion();

                        asientoTemp = new Asiento(asiento, clase, ubicacion);
                        asientoTemp.setPasajero(pasajero);

                        System.out.println("|| Nombre del pasajero: " + nombre);
                        System.out.println("|| Identificacion del pasajero: " + id);
                        System.out.println("|| Destino del pasajero: " + destino);
                        System.out.println("|| Clase del asiento: " + clase);
                        System.out.println("|| Ubicacion del asiento: " + ubicacion);
                        System.out.println("|| Numero del asiento: " + asiento);
                        System.out.println("|| Costo del boleto del pasajero: $" + costoBoleto);
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

                        System.out.println("¿Desea confirmar la reservación, (S/N)?");
                        respuesta = lol.nextLine();

                        if (respuesta.equalsIgnoreCase("s") || respuesta.equalsIgnoreCase("S")) {
                            this.nave.ejecutivos[asiento - 1] = asientoTemp;

                            System.out.println("Se ha confirmado la reservación...");
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        } else {
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                            System.out.println("||           ALGO SALIO MAL                ||");
                            System.out.println("||        ERROR, RESPUESTA INVALIDA        ||");
                            System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
                            System.out.println("||        Presione <Enter> para continuar  ||");
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                            lol.nextLine();
                            lol.nextLine();
                            System.out.println("¿Desea confirmar la reservación, (S/N)?");
                            respuesta = lol.nextLine();
                            if (respuesta.equalsIgnoreCase("s") || respuesta.equalsIgnoreCase("S")) {
                                this.nave.ejecutivos[asiento - 1] = asientoTemp;

                                System.out.println("Se ha confirmado la reservación...");
                                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                            }
                            if (respuesta.equalsIgnoreCase("N") || respuesta.equalsIgnoreCase("n")) {
                                mostrarMenuPrincipal();
                            }
                        }
                        System.out.println("¿Se desea continuar con el Registro de Reservaciones, (S/N)?");
                        respuesta = lol.nextLine();
                        if (respuesta.equalsIgnoreCase("S") || respuesta.equalsIgnoreCase("s")) {
                            registrarReservaciones();
                        }
                        if (respuesta.equalsIgnoreCase("n") || respuesta.equalsIgnoreCase("N")) {
                            mostrarMenuPrincipal();
                        }
                    }

                } else {
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    System.out.println("||        ALGO SALIO MAL                   ||");
                    System.out.println("||      ERROR, EL ASIENTO ESTÁ OCUPADO     ||");
                    System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
                    System.out.println("||        Presione <Enter> para continuar  ||");
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    lol.nextLine();
                    lol.nextLine();
                    return;
                }
            }
        }

        for (Asiento asientoTemp : nave.economicos) {
            if (asientoTemp.getAsiento() == asiento) {
                if (asientoTemp.getPasajero() == null) {

                    System.out.println("¿Se desea continuar con el Registro de Reservaciones, (S/N)?");
                    lol.nextLine();

                    String respuesta = lol.nextLine();

                    if (!respuesta.equalsIgnoreCase("S") && !respuesta.equalsIgnoreCase("N") && !respuesta.equalsIgnoreCase("s") && !respuesta.equalsIgnoreCase("n")) {
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        System.out.println("||        ALGO SALIO MAL                   ||");
                        System.out.println("||        LA RESPUESTA NO ES VÁLIDA        ||");
                        System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
                        System.out.println("||        Presione <Enter> para continuar  ||");
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    }

                    if (respuesta.equalsIgnoreCase("N")) {
                        break;
                    }
                    if (respuesta.equalsIgnoreCase("S")) {
                        System.out.println("Ingrese el nombre del Pasajero");
                        nombre = lol.nextLine();
                        for (int x = 0; x < nombre.length(); x++) {
                            char c = nombre.charAt(x);
                            // Si no está entre a y z, ni entre A y Z, ni es un espacio
                            if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == ' ')) {
                                System.out.println("ERROR, FAVOR DE INTRODUCIR UN NOMBRE VALIDO");
                                System.out.println("EL NOMBRE DEBE SER PARTE DEL ABECEDARIO |A-Z|");
                                nombre = lol.nextLine();

                            }
                        }

                        System.out.println("|| Ingrese el ID del Pasajero ||");
                        id = lol.nextLine();

                        System.out.println("|| Ingrese el Destino del Pasajero ||");
                        destino = lol.nextLine();
                        if (!destino.equalsIgnoreCase("Luna") && !destino.equalsIgnoreCase("Titan") && !destino.equalsIgnoreCase("Europa")) {
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                            System.out.println("||        ALGO SALIO MAL                   ||");
                            System.out.println("||        LA RESPUESTA NO ES VÁLIDA        ||");
                            System.out.println("||  FAVOR DE INGRESAR UNA OPCION VALIDA    ||");
                            System.out.println("||        Presione <Enter> para continuar  ||");
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                            destino = lol.nextLine();
                        }
                        ob.setAsiento(asiento);
                        clase = ob.getClase();
                        pasajero.setNombrePasajero(nombre);
                        pasajero.setIdentificacionPasajero(id);
                        pasajero.setDestinoPasajero(destino);
                        costoBoleto = pasajero.obtenerCostoBoletoPasajero(clase);
                        ubicacion = ob.getUbicacion();

                        asientoTemp = new Asiento(asiento, clase, ubicacion);
                        asientoTemp.setPasajero(pasajero);

                        System.out.println("|| Nombre del pasajero: " + nombre);
                        System.out.println("|| Identificacion del pasajero: " + id);
                        System.out.println("|| Destino del pasajero: " + destino);
                        System.out.println("|| Clase del asiento: " + clase);
                        System.out.println("|| Ubicacion del asiento: " + ubicacion);
                        System.out.println("|| Numero del asiento: " + asiento);
                        System.out.println("|| Costo del boleto del pasajero: $" + costoBoleto);
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

                        System.out.println("¿Desea confirmar la reservación, (S/N)?");
                        respuesta = lol.nextLine();

                        if (respuesta.equalsIgnoreCase("s") || respuesta.equalsIgnoreCase("S")) {
                            this.nave.economicos[asiento - 5] = asientoTemp;

                            System.out.println("Se ha confirmado la reservación...");
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        } else {
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                            System.out.println("||           ALGO SALIO MAL                ||");
                            System.out.println("||        ERROR, RESPUESTA INVALIDA        ||");
                            System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
                            System.out.println("||        Presione <Enter> para continuar  ||");
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                            lol.nextLine();
                            lol.nextLine();
                            System.out.println("¿Desea confirmar la reservación, (S/N)?");
                            respuesta = lol.nextLine();
                            if (respuesta.equalsIgnoreCase("s") || respuesta.equalsIgnoreCase("S")) {
                                this.nave.economicos[asiento - 5] = asientoTemp;

                                System.out.println("Se ha confirmado la reservación...");
                                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                            }
                            if (respuesta.equalsIgnoreCase("N") || respuesta.equalsIgnoreCase("n")) {
                                mostrarMenuPrincipal();
                            }
                        }
                        System.out.println("¿Se desea continuar con el Registro de Reservaciones, (S/N)?");
                        respuesta = lol.nextLine();
                        if (respuesta.equalsIgnoreCase("S") || respuesta.equalsIgnoreCase("s")) {
                            registrarReservaciones();
                        }
                        if (respuesta.equalsIgnoreCase("n") || respuesta.equalsIgnoreCase("N")) {
                            mostrarMenuPrincipal();
                        }
                    }

                } else {
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    System.out.println("||        ALGO SALIO MAL                   ||");
                    System.out.println("||      ERROR, EL ASIENTO ESTÁ OCUPADO     ||");
                    System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
                    System.out.println("||        Presione <Enter> para continuar  ||");
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    lol.nextLine();
                    lol.nextLine();
                    return;

                }
            }
        }

    }

    public void eliminarReservaciones() {
        Pasajero pasajero;
        Asiento ob = new Asiento();
        int asiento;
        mostrarMapaOcupacion();
        Scanner lol = new Scanner(System.in);
        System.out.println("|| INGRESE EL ASIENTO QUE DESEE ELIMINAR ||");
        asiento = lol.nextInt();

        if (asiento == 0) {
            mostrarMenuPrincipal();
        }
        if (asiento < 0 && asiento > 28) {
            System.out.println("El número de asiento es invalido.");
            System.out.println("Favor de seleccionar uno entre 1-28");
            asiento = lol.nextInt();
        }

        for (Asiento asientoTemp : nave.ejecutivos) {
            if (asientoTemp.getAsiento() == asiento) {
                if (asientoTemp.getPasajero() != null) {
                    pasajero = asientoTemp.getPasajero();
                    System.out.println("¿Se desea continuar con la Eliminiacion de reservaciones, (S/N)?");
                    lol.nextLine();

                    String respuesta = lol.nextLine();

                    if (!respuesta.equalsIgnoreCase("S") && !respuesta.equalsIgnoreCase("N") && !respuesta.equalsIgnoreCase("s") && !respuesta.equalsIgnoreCase("n")) {
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        System.out.println("||        ALGO SALIO MAL                   ||");
                        System.out.println("||        LA RESPUESTA NO ES VÁLIDA        ||");
                        System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
                        System.out.println("||        Presione <Enter> para continuar  ||");
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        lol.nextLine();
                        lol.nextLine();
                        System.out.println("Ingrese una respuesta valida (S/N)");
                        respuesta = lol.nextLine();
                    }

                    if (respuesta.equalsIgnoreCase("N") || respuesta.equalsIgnoreCase("n")) {
                        mostrarMenuPrincipal();
                    }
                    if (respuesta.equalsIgnoreCase("S") || respuesta.equalsIgnoreCase("s")) {
                        System.out.println("|| Nombre del pasajero: " + pasajero.getNombrePasajero());
                        System.out.println("|| Identificacion del pasajero: " + pasajero.getIdentificacionPasajero());
                        System.out.println("|| Destino del pasajero: " + pasajero.getDestinoPasajero());
                        System.out.println("|| Clase del asiento: " + asientoTemp.getClase());
                        System.out.println("|| Ubicacion del asiento: " + asientoTemp.getUbicacion());
                        System.out.println("|| Numero del asiento: " + asientoTemp.getAsiento());
                        System.out.println("|| Costo del boleto del pasajero: $" + asientoTemp.getPasajero().obtenerCostoBoletoPasajero(asientoTemp.getClase()));
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    }

                    System.out.println("¿Se confirma la eliminación de la reservación, (S/N)?");
                    respuesta = lol.nextLine();
                    if (respuesta.equalsIgnoreCase("s") || respuesta.equalsIgnoreCase("S")) {
                        this.nave.ejecutivos[asiento - 1] = new Asiento(asiento);

                        System.out.println("Se ha eliminado la reservación...");
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    }
                    if (respuesta.equalsIgnoreCase("N") || respuesta.equalsIgnoreCase("n")) {
                        mostrarMenuPrincipal();
                    }

                    System.out.println("¿Se desea continuar con la eliminación de Reservaciones, (S/N)?");
                    respuesta = lol.nextLine();
                    if (respuesta.equalsIgnoreCase("S") || respuesta.equalsIgnoreCase("s")) {
                        eliminarReservaciones();
                    }
                    if (respuesta.equalsIgnoreCase("n") || respuesta.equalsIgnoreCase("N")) {
                        mostrarMenuPrincipal();
                    }

                } else {
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    System.out.println("||        ALGO SALIO MAL                   ||");
                    System.out.println("||      ERROR, EL ASIENTO ESTÁ DESOCUPADO     ||");
                    System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
                    System.out.println("||        Presione <Enter> para continuar  ||");
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    lol.nextLine();
                    lol.nextLine();
                    return;
                }
            }

        }

        for (Asiento asientoTemp : nave.economicos) {
            if (asientoTemp.getAsiento() == asiento) {
                if (asientoTemp.getPasajero() != null) {
                    pasajero = asientoTemp.getPasajero();
                    System.out.println("¿Se desea continuar con la Eliminiacion de reservaciones, (S/N)?");
                    lol.nextLine();

                    String respuesta = lol.nextLine();

                    if (!respuesta.equalsIgnoreCase("S") && !respuesta.equalsIgnoreCase("N") && !respuesta.equalsIgnoreCase("s") && !respuesta.equalsIgnoreCase("n")) {
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        System.out.println("||        ALGO SALIO MAL                   ||");
                        System.out.println("||        LA RESPUESTA NO ES VÁLIDA        ||");
                        System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
                        System.out.println("||        Presione <Enter> para continuar  ||");
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        lol.nextLine();
                        lol.nextLine();
                        System.out.println("Ingrese una respuesta valida (S/N)");
                        respuesta = lol.nextLine();
                    }

                    if (respuesta.equalsIgnoreCase("N") || respuesta.equalsIgnoreCase("n")) {
                        mostrarMenuPrincipal();
                    }
                    if (respuesta.equalsIgnoreCase("S") || respuesta.equalsIgnoreCase("s")) {
                        System.out.println("|| Nombre del pasajero: " + pasajero.getNombrePasajero());
                        System.out.println("|| Identificacion del pasajero: " + pasajero.getIdentificacionPasajero());
                        System.out.println("|| Destino del pasajero: " + pasajero.getDestinoPasajero());
                        System.out.println("|| Clase del asiento: " + asientoTemp.getClase());
                        System.out.println("|| Ubicacion del asiento: " + asientoTemp.getUbicacion());
                        System.out.println("|| Numero del asiento: " + asientoTemp.getAsiento());
                        System.out.println("|| Costo del boleto del pasajero: $" + asientoTemp.getPasajero().obtenerCostoBoletoPasajero(asientoTemp.getClase()));
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    }

                    System.out.println("¿Se confirma la eliminación de la reservación, (S/N)?");
                    respuesta = lol.nextLine();
                    if (respuesta.equalsIgnoreCase("s") || respuesta.equalsIgnoreCase("S")) {
                        this.nave.economicos[asiento - 5] = new Asiento(asiento);

                        System.out.println("Se ha eliminado la reservación...");
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    }
                    if (respuesta.equalsIgnoreCase("N") || respuesta.equalsIgnoreCase("n")) {
                        mostrarMenuPrincipal();
                    }

                    System.out.println("¿Se desea continuar con la eliminación de Reservaciones, (S/N)?");
                    respuesta = lol.nextLine();
                    if (respuesta.equalsIgnoreCase("S") || respuesta.equalsIgnoreCase("s")) {
                        eliminarReservaciones();
                    }
                    if (respuesta.equalsIgnoreCase("n") || respuesta.equalsIgnoreCase("N")) {
                        mostrarMenuPrincipal();
                    }

                } else {
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    System.out.println("||        ALGO SALIO MAL                   ||");
                    System.out.println("||    ERROR, EL ASIENTO ESTÁ DESOCUPADO    ||");
                    System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
                    System.out.println("||        Presione <Enter> para continuar  ||");
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    lol.nextLine();
                    lol.nextLine();
                    return;
                }
            }

        }

    }/*llave metodo eliminarReservaciones() */

    public void modificarReservaciones() {
        Pasajero pasajero = new Pasajero();
        Asiento ob = new Asiento();
        int asiento;
        float costoBoleto;
        String nombre, destino, clase, ubicacion, id;
        mostrarMapaOcupacion();
        Scanner lol = new Scanner(System.in);
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("|| INGRESE EL ASIENTO QUE DESEE MODIFICAR ||");
        System.out.println("|| EN CASO DE QUERER REGRESAR AL MENU     ||");
        System.out.println("|| INGRESAR 0, EN CASO CONTRARIO, OMITIR  ||");
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        asiento = lol.nextInt();

        if (asiento == 0) {
            mostrarMenuPrincipal();
        }
        if (asiento < 0 && asiento > 28) {
            System.out.println("El número de asiento es invalido.");
            System.out.println("Favor de seleccionar uno entre 1-28");
            asiento = lol.nextInt();
        }
        for (Asiento asientoTemp : nave.ejecutivos) {
            if (asientoTemp.getAsiento() == asiento) {
                if (asientoTemp.getPasajero() != null) {
                    pasajero = asientoTemp.getPasajero();
                    System.out.println("¿Se desea continuar con la Modificacion de reservaciones, (S/N)?");
                    lol.nextLine();
                    String respuesta = lol.nextLine();
                    if (!respuesta.equalsIgnoreCase("S") && !respuesta.equalsIgnoreCase("N") && !respuesta.equalsIgnoreCase("s") && !respuesta.equalsIgnoreCase("n")) {
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        System.out.println("||        ALGO SALIO MAL                   ||");
                        System.out.println("||        LA RESPUESTA NO ES VÁLIDA        ||");
                        System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
                        System.out.println("||        Presione <Enter> para continuar  ||");
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        lol.nextLine();
                        lol.nextLine();
                        System.out.println("Ingrese una respuesta valida (S/N)");
                        respuesta = lol.nextLine();
                    }

                    if (respuesta.equalsIgnoreCase("N") || respuesta.equalsIgnoreCase("n")) {
                        mostrarMenuPrincipal();
                    }
                    if (respuesta.equalsIgnoreCase("S") || respuesta.equalsIgnoreCase("s")) {
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        System.out.println("|| Nombre del pasajero: " + pasajero.getNombrePasajero());
                        System.out.println("|| Identificacion del pasajero: " + pasajero.getIdentificacionPasajero());
                        System.out.println("|| Destino del pasajero: " + pasajero.getDestinoPasajero());
                        System.out.println("|| Clase del asiento: " + asientoTemp.getClase());
                        System.out.println("|| Ubicacion del asiento: " + asientoTemp.getUbicacion());
                        System.out.println("|| Numero del asiento: " + asientoTemp.getAsiento());
                        System.out.println("|| Costo del boleto del pasajero: $" + asientoTemp.getPasajero().obtenerCostoBoletoPasajero(asientoTemp.getClase()));
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        System.out.println("");
                        System.out.println("Se confirma el ingreso de los datos a modificar, (S/N)?");
                        respuesta = lol.nextLine();
                        if (!respuesta.equalsIgnoreCase("S") && !respuesta.equalsIgnoreCase("N") && !respuesta.equalsIgnoreCase("s") && !respuesta.equalsIgnoreCase("n")) {
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                            System.out.println("||        ALGO SALIO MAL                   ||");
                            System.out.println("||        LA RESPUESTA NO ES VÁLIDA        ||");
                            System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
                            System.out.println("||        Presione <Enter> para continuar  ||");
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                            lol.nextLine();
                            lol.nextLine();
                            System.out.println("Ingrese una respuesta valida (S/N)");
                            respuesta = lol.nextLine();
                        }
                        if (respuesta.equalsIgnoreCase("N") || respuesta.equalsIgnoreCase("n")) {
                            mostrarMenuPrincipal();
                        }
                        if (respuesta.equalsIgnoreCase("S") || respuesta.equalsIgnoreCase("s")) {
                            System.out.println("Ingrese el nombre del Pasajero");
                            nombre = lol.nextLine();
                            for (int x = 0; x < nombre.length(); x++) {
                                char c = nombre.charAt(x);
                                // Si no está entre a y z, ni entre A y Z, ni es un espacio
                                if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == ' ')) {
                                    System.out.println("ERROR, FAVOR DE INTRODUCIR UN NOMBRE VALIDO");
                                    System.out.println("EL NOMBRE DEBE SER PARTE DEL ABECEDARIO |A-Z|");
                                    nombre = lol.nextLine();

                                }
                            }

                            System.out.println("|| Ingrese el ID del Pasajero ||");
                            id = lol.nextLine();

                            System.out.println("|| Ingrese el Destino del Pasajero ||");

                            destino = lol.nextLine();

                            if (!destino.equalsIgnoreCase("Luna") && !destino.equalsIgnoreCase("Titan") && !destino.equalsIgnoreCase("Europa")) {
                                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                                System.out.println("||        ALGO SALIO MAL                   ||");
                                System.out.println("||        LA RESPUESTA NO ES VÁLIDA        ||");
                                System.out.println("||  FAVOR DE INGRESAR UNA OPCION VALIDA    ||");
                                System.out.println("||        Presione <Enter> para continuar  ||");
                                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                                destino = lol.nextLine();
                            }
                            ob.setAsiento(asiento);
                            clase = ob.getClase();
                            pasajero.setNombrePasajero(nombre);
                            pasajero.setIdentificacionPasajero(id);
                            pasajero.setDestinoPasajero(destino);
                            costoBoleto = pasajero.obtenerCostoBoletoPasajero(clase);
                            ubicacion = ob.getUbicacion();

                            asientoTemp = new Asiento(asiento, clase, ubicacion);
                            asientoTemp.setPasajero(pasajero);

                            System.out.println("|| Nombre del pasajero: " + nombre);
                            System.out.println("|| Identificacion del pasajero: " + id);
                            System.out.println("|| Destino del pasajero: " + destino);
                            System.out.println("|| Clase del asiento: " + clase);
                            System.out.println("|| Ubicacion del asiento: " + ubicacion);
                            System.out.println("|| Numero del asiento: " + asiento);
                            System.out.println("|| Costo del boleto del pasajero: $" + costoBoleto);
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

                        }

                        System.out.println("¿Se confirma la modificación de la reservación, (S/N)?");
                        respuesta = lol.nextLine();
                        if (!respuesta.equalsIgnoreCase("S") && !respuesta.equalsIgnoreCase("N") && !respuesta.equalsIgnoreCase("s") && !respuesta.equalsIgnoreCase("n")) {
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                            System.out.println("||        ALGO SALIO MAL                   ||");
                            System.out.println("||        LA RESPUESTA NO ES VÁLIDA        ||");
                            System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
                            System.out.println("||        Presione <Enter> para continuar  ||");
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                            lol.nextLine();
                            lol.nextLine();
                            System.out.println("Ingrese una respuesta valida (S/N)");
                            respuesta = lol.nextLine();
                        }
                        if (respuesta.equalsIgnoreCase("N") || respuesta.equalsIgnoreCase("n")) {
                            mostrarMenuPrincipal();
                        }
                        if (respuesta.equalsIgnoreCase("S") || respuesta.equalsIgnoreCase("s")) {
                            this.nave.ejecutivos[asiento - 1] = asientoTemp;
                            
                        }
                        
                            System.out.println("¿Se desea continuar con la Modificación de Reservaciones, (S/N)?");
                            respuesta = lol.nextLine();
                            if (respuesta.equalsIgnoreCase("S") || respuesta.equalsIgnoreCase("s")) {
                                this.modificarReservaciones();
                            }
                            if (respuesta.equalsIgnoreCase("n") || respuesta.equalsIgnoreCase("N")) {
                                mostrarMenuPrincipal();
                            }
                        }
                    } else {
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        System.out.println("||        ALGO SALIO MAL                   ||");
                        System.out.println("||    ERROR, EL ASIENTO ESTÁ DESOCUPADO    ||");
                        System.out.println("|| FAVOR DE SELECCIONAR UN ASIENTO OCUPADO ||");
                        System.out.println("||        Presione <Enter> para continuar  ||");
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        lol.nextLine();
                        lol.nextLine();
                        return;
                    }
                }
            }
        for (Asiento asientoTemp : nave.economicos) {
            if (asientoTemp.getAsiento() == asiento) {
                if (asientoTemp.getPasajero() != null) {
                    pasajero = asientoTemp.getPasajero();
                    System.out.println("¿Se desea continuar con la Modificacion de reservaciones, (S/N)?");
                    lol.nextLine();
                    String respuesta = lol.nextLine();
                    if (!respuesta.equalsIgnoreCase("S") && !respuesta.equalsIgnoreCase("N") && !respuesta.equalsIgnoreCase("s") && !respuesta.equalsIgnoreCase("n")) {
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        System.out.println("||        ALGO SALIO MAL                   ||");
                        System.out.println("||        LA RESPUESTA NO ES VÁLIDA        ||");
                        System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
                        System.out.println("||        Presione <Enter> para continuar  ||");
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        lol.nextLine();
                        lol.nextLine();
                        System.out.println("Ingrese una respuesta valida (S/N)");
                        respuesta = lol.nextLine();
                    }

                    if (respuesta.equalsIgnoreCase("N") || respuesta.equalsIgnoreCase("n")) {
                        mostrarMenuPrincipal();
                    }
                    if (respuesta.equalsIgnoreCase("S") || respuesta.equalsIgnoreCase("s")) {
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        System.out.println("|| Nombre del pasajero: " + pasajero.getNombrePasajero());
                        System.out.println("|| Identificacion del pasajero: " + pasajero.getIdentificacionPasajero());
                        System.out.println("|| Destino del pasajero: " + pasajero.getDestinoPasajero());
                        System.out.println("|| Clase del asiento: " + asientoTemp.getClase());
                        System.out.println("|| Ubicacion del asiento: " + asientoTemp.getUbicacion());
                        System.out.println("|| Numero del asiento: " + asientoTemp.getAsiento());
                        System.out.println("|| Costo del boleto del pasajero: $" + asientoTemp.getPasajero().obtenerCostoBoletoPasajero(asientoTemp.getClase()));
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        System.out.println("");
                        System.out.println("Se confirma el ingreso de los datos a modificar, (S/N)?");
                        respuesta = lol.nextLine();
                        if (!respuesta.equalsIgnoreCase("S") && !respuesta.equalsIgnoreCase("N") && !respuesta.equalsIgnoreCase("s") && !respuesta.equalsIgnoreCase("n")) {
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                            System.out.println("||        ALGO SALIO MAL                   ||");
                            System.out.println("||        LA RESPUESTA NO ES VÁLIDA        ||");
                            System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
                            System.out.println("||        Presione <Enter> para continuar  ||");
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                            lol.nextLine();
                            lol.nextLine();
                            System.out.println("Ingrese una respuesta valida (S/N)");
                            respuesta = lol.nextLine();
                        }
                        if (respuesta.equalsIgnoreCase("N") || respuesta.equalsIgnoreCase("n")) {
                            mostrarMenuPrincipal();
                        }
                        if (respuesta.equalsIgnoreCase("S") || respuesta.equalsIgnoreCase("s")) {
                            System.out.println("Ingrese el nombre del Pasajero");
                            nombre = lol.nextLine();
                            for (int x = 0; x < nombre.length(); x++) {
                                char c = nombre.charAt(x);
                                // Si no está entre a y z, ni entre A y Z, ni es un espacio
                                if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == ' ')) {
                                    System.out.println("ERROR, FAVOR DE INTRODUCIR UN NOMBRE VALIDO");
                                    System.out.println("EL NOMBRE DEBE SER PARTE DEL ABECEDARIO |A-Z|");
                                    nombre = lol.nextLine();

                                }
                            }

                            System.out.println("|| Ingrese el ID del Pasajero ||");
                            id = lol.nextLine();

                            System.out.println("|| Ingrese el Destino del Pasajero ||");

                            destino = lol.nextLine();

                            if (!destino.equalsIgnoreCase("Luna") && !destino.equalsIgnoreCase("Titan") && !destino.equalsIgnoreCase("Europa")) {
                                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                                System.out.println("||        ALGO SALIO MAL                   ||");
                                System.out.println("||        LA RESPUESTA NO ES VÁLIDA        ||");
                                System.out.println("||  FAVOR DE INGRESAR UNA OPCION VALIDA    ||");
                                System.out.println("||        Presione <Enter> para continuar  ||");
                                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                                destino = lol.nextLine();
                            }
                            ob.setAsiento(asiento);
                            clase = ob.getClase();
                            pasajero.setNombrePasajero(nombre);
                            pasajero.setIdentificacionPasajero(id);
                            pasajero.setDestinoPasajero(destino);
                            costoBoleto = pasajero.obtenerCostoBoletoPasajero(clase);
                            ubicacion = ob.getUbicacion();

                            asientoTemp = new Asiento(asiento, clase, ubicacion);
                            asientoTemp.setPasajero(pasajero);

                            System.out.println("|| Nombre del pasajero: " + nombre);
                            System.out.println("|| Identificacion del pasajero: " + id);
                            System.out.println("|| Destino del pasajero: " + destino);
                            System.out.println("|| Clase del asiento: " + clase);
                            System.out.println("|| Ubicacion del asiento: " + ubicacion);
                            System.out.println("|| Numero del asiento: " + asiento);
                            System.out.println("|| Costo del boleto del pasajero: $" + costoBoleto);
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

                        }

                        System.out.println("¿Se confirma la modificación de la reservación, (S/N)?");
                        respuesta = lol.nextLine();
                        if (!respuesta.equalsIgnoreCase("S") && !respuesta.equalsIgnoreCase("N") && !respuesta.equalsIgnoreCase("s") && !respuesta.equalsIgnoreCase("n")) {
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                            System.out.println("||        ALGO SALIO MAL                   ||");
                            System.out.println("||        LA RESPUESTA NO ES VÁLIDA        ||");
                            System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
                            System.out.println("||        Presione <Enter> para continuar  ||");
                            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                            lol.nextLine();
                            lol.nextLine();
                            System.out.println("Ingrese una respuesta valida (S/N)");
                            respuesta = lol.nextLine();
                        }
                        if (respuesta.equalsIgnoreCase("N") || respuesta.equalsIgnoreCase("n")) {
                            mostrarMenuPrincipal();
                        }
                        if (respuesta.equalsIgnoreCase("S") || respuesta.equalsIgnoreCase("s")) {
                            this.nave.economicos[asiento - 5] = asientoTemp;
                            
                        }
                        
                            System.out.println("¿Se desea continuar con la Modificación de Reservaciones, (S/N)?");
                            respuesta = lol.nextLine();
                            if (respuesta.equalsIgnoreCase("S") || respuesta.equalsIgnoreCase("s")) {
                                this.modificarReservaciones();
                            }
                            if (respuesta.equalsIgnoreCase("n") || respuesta.equalsIgnoreCase("N")) {
                                mostrarMenuPrincipal();
                            }
                        }
                    } else {
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        System.out.println("||        ALGO SALIO MAL                   ||");
                        System.out.println("||    ERROR, EL ASIENTO ESTÁ DESOCUPADO    ||");
                        System.out.println("|| FAVOR DE SELECCIONAR UN ASIENTO OCUPADO ||");
                        System.out.println("||        Presione <Enter> para continuar  ||");
                        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        lol.nextLine();
                        lol.nextLine();
                        return;
                    }
                }
            }
        }
    
    

    public void mostrarSubmenuConsultaReservaciones() {
        System.out.println("Estas en *Mostrar Submenu Consulta Reservaciones");
        int sn = 0;
        Scanner lol = new Scanner(System.in);
        System.out.println("||                    Listado de opciones                    ||");
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("|| 1.  Consulta de Reservaciones por Nombre del Pasajero.    ||");
        System.out.println("|| 2.  Consulta de Reservaciones por Número del Asiento      ||");
        System.out.println("|| 3.  Volver al menú principal                              ||");
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("||         Ingrese la opción que desea seleccionar           ||");
        try {
            sn = lol.nextByte();
        } catch (Exception e) {
        }
        switch (sn) {
            case 1: {
                consultarReservacionesNombrePasajero();
                break;
            }
            case 2: {
                consultarReservacionesNumeroAsiento();
                break;
            }
            case 3: {
                return;
            }
            default: {
                impErrorSubmenu();
            }
        }

    }

    public void consultarReservacionesNombrePasajero() {
        Asiento asiento = null;
        String respuesta;
        Scanner lol = new Scanner(System.in);
        System.out.println("|| INGRESE EL NOMBRE DEL PASAJERO ||");
        String nombre = lol.nextLine();
        for (int x = 0; x < nombre.length(); x++) {
            char c = nombre.charAt(x);
            // Si no está entre a y z, ni entre A y Z, ni es un espacio
            if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == ' ')) {
                System.out.println("ERROR, FAVOR DE INTRODUCIR UN NOMBRE VALIDO");
                System.out.println("EL NOMBRE DEBE SER PARTE DEL ABECEDARIO |A-Z|");
                nombre = lol.nextLine();
            }
        }

        if (nombre.equalsIgnoreCase("Fin")) {
            return;
        }

        boolean estaRegistrado = false;

        for (Asiento asientoTemp : nave.ejecutivos) {
            if (asientoTemp.getPasajero() != null && asientoTemp.getPasajero().getNombrePasajero().equalsIgnoreCase(nombre)) {
                estaRegistrado = true;
                asiento = asientoTemp;
                break;
            }
        }

        for (Asiento asientoTemp : nave.economicos) {
            if (asientoTemp.getPasajero() != null && asientoTemp.getPasajero().getNombrePasajero().equalsIgnoreCase(nombre)) {
                estaRegistrado = true;
                asiento = asientoTemp;
                break;
            }
        }

        if (!estaRegistrado) {
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            System.out.println("||        ALGO SALIO MAL                   ||");
            System.out.println("||     EL PASAJERO NO ESTA REGISTRADO      ||");
            System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
            System.out.println("||        Presione <Enter> para continuar  ||");
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            lol.nextLine();

            while (true) {
                System.out.println("¿Se desea continuar con la busqueda por nombre, (S/N)?");

                respuesta = lol.nextLine();
                if (respuesta.equalsIgnoreCase("S") || respuesta.equalsIgnoreCase("s")) {
                    consultarReservacionesNombrePasajero();
                    break;
                }
                if (respuesta.equalsIgnoreCase("n") || respuesta.equalsIgnoreCase("N")) {
                    this.mostrarSubmenuConsultaReservaciones();
                    break;
                } else {
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    System.out.println("||        ALGO SALIO MAL                   ||");
                    System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
                    System.out.println("||        Presione <Enter> para continuar  ||");
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    lol.nextLine();
                }
            }

            return;
        }

        System.out.println("¿Se desea continuar con la busqueda por nombre, (S/N)?");
        respuesta = lol.nextLine();
        if (respuesta.equalsIgnoreCase("n")) {
            return;
        }

        System.out.println("|| Nombre del pasajero: " + asiento.getPasajero().getNombrePasajero());
        System.out.println("|| Identificacion del pasajero: " + asiento.getPasajero().getIdentificacionPasajero());
        System.out.println("|| Destino del pasajero: " + asiento.getPasajero().getDestinoPasajero());
        System.out.println("|| Clase del asiento: " + asiento.getClase());
        System.out.println("|| Ubicacion del asiento: " + asiento.getUbicacion());
        System.out.println("|| Numero del asiento: " + asiento.getAsiento());
        System.out.println("|| Costo del boleto del pasajero: $" + asiento.getPasajero().obtenerCostoBoletoPasajero(asiento.getClase()));
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        while (true) {
            System.out.println("¿Desea realizar una nueva busqueda, (S/N)?");

            respuesta = lol.nextLine();
            if (respuesta.equalsIgnoreCase("S") || respuesta.equalsIgnoreCase("s")) {
                consultarReservacionesNombrePasajero();
                break;
            }
            if (respuesta.equalsIgnoreCase("n") || respuesta.equalsIgnoreCase("N")) {
                this.mostrarSubmenuConsultaReservaciones();
                break;
            } else {
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                System.out.println("||        ALGO SALIO MAL                   ||");
                System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
                System.out.println("||        Presione <Enter> para continuar  ||");
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                lol.nextLine();
            }
        }
    }

    public void consultarReservacionesNumeroAsiento() {
        Asiento asiento = null;
        String respuesta;
        mostrarMapaOcupacion();
        int noAsiento = 0;
        Scanner lol = new Scanner(System.in);

        try {
            System.out.println("|| INGRESE EL NUMERO DE ASIENTO ||");
            noAsiento = lol.nextInt();
        } catch (NumberFormatException er) {
            System.out.println("ERROR, FAVOR DE INTRODUCIR UN VALOR NUMÉRICO");
            lol.nextLine();
        }

        if (noAsiento == 0) {
            this.mostrarSubmenuConsultaReservaciones();
            return;
        }

        if (noAsiento < 0 || noAsiento > 28) {
            this.consultarReservacionesNumeroAsiento();
            return;
        }

        boolean tieneReservacion = false;

        for (Asiento asientoTemp : nave.ejecutivos) {
            if (asientoTemp.getPasajero() != null && asientoTemp.getAsiento() == noAsiento) {
                tieneReservacion = true;
                asiento = asientoTemp;
                break;
            }
        }

        for (Asiento asientoTemp : nave.economicos) {
            if (asientoTemp.getPasajero() != null && asientoTemp.getAsiento() == noAsiento) {
                tieneReservacion = true;
                asiento = asientoTemp;
                break;
            }
        }

        if (!tieneReservacion) {
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            System.out.println("||        ALGO SALIO MAL                   ||");
            System.out.println("||     EL ASIENTO NO ESTÁ OCUPADO          ||");
            System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
            System.out.println("||        Presione <Enter> para continuar  ||");
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            lol.nextLine();

            while (true) {
                System.out.println("¿Se desea continuar con la consulta de reservaciones por asiento, (S/N)?");

                respuesta = lol.nextLine();
                if (respuesta.equalsIgnoreCase("S") || respuesta.equalsIgnoreCase("s")) {
                    consultarReservacionesNumeroAsiento();
                    break;
                }
                if (respuesta.equalsIgnoreCase("n") || respuesta.equalsIgnoreCase("N")) {
                    this.mostrarSubmenuConsultaReservaciones();
                    break;
                } else {
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    System.out.println("||        ALGO SALIO MAL                   ||");
                    System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
                    System.out.println("||        Presione <Enter> para continuar  ||");
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    lol.nextLine();
                }
            }

            return;
        }

        System.out.println("¿Se desea continuar con la consulta de reservaciones por asiento, (S/N)?");
        respuesta = lol.nextLine();
        if (respuesta.equalsIgnoreCase("n")) {
            return;
        }

        System.out.println("|| Nombre del pasajero: " + asiento.getPasajero().getNombrePasajero());
        System.out.println("|| Identificacion del pasajero: " + asiento.getPasajero().getIdentificacionPasajero());
        System.out.println("|| Destino del pasajero: " + asiento.getPasajero().getDestinoPasajero());
        System.out.println("|| Clase del asiento: " + asiento.getClase());
        System.out.println("|| Ubicacion del asiento: " + asiento.getUbicacion());
        System.out.println("|| Numero del asiento: " + asiento.getAsiento());
        System.out.println("|| Costo del boleto del pasajero: $" + asiento.getPasajero().obtenerCostoBoletoPasajero(asiento.getClase()));
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        while (true) {
            System.out.println("¿Desea realizar una nueva busqueda, (S/N)?");

            respuesta = lol.nextLine();
            if (respuesta.equalsIgnoreCase("S") || respuesta.equalsIgnoreCase("s")) {
                consultarReservacionesNumeroAsiento();
                break;
            }
            if (respuesta.equalsIgnoreCase("n") || respuesta.equalsIgnoreCase("N")) {
                this.mostrarSubmenuConsultaReservaciones();
                break;

            } else {
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                System.out.println("||        ALGO SALIO MAL                   ||");
                System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
                System.out.println("||        Presione <Enter> para continuar  ||");
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                lol.nextLine();
            }
        }
    }

    public void mostrarMapaOcupacion() {
        Asiento asiento = new Asiento();
        for (int i = 0; i < nave.ejecutivos.length; i++) {
            asiento = nave.ejecutivos[i];

            System.out.print("| " + asiento.getAsiento() + " ");

            if (asiento.getPasajero() != null) {
                if (asiento.getPasajero().getDestinoPasajero().equalsIgnoreCase("Luna")) {
                    System.out.print("LUN" + " ");
                }
                if (asiento.getPasajero().getDestinoPasajero().equalsIgnoreCase("Europa")) {
                    System.out.print("EUR" + " ");
                }
                if (asiento.getPasajero().getDestinoPasajero().equalsIgnoreCase("Titan")) {
                    System.out.print("TAN" + " ");
                }
            } else {
                System.out.print("TIC");
            }

            if (i == 1) {
                System.out.print("|   ");
            }

            if (i == 3) {
                System.out.println("|");
            }
        }
        System.out.println("");

        for (int i = 0; i < nave.economicos.length; i++) {
            asiento = nave.economicos[i];

            System.out.print("| " + asiento.getAsiento() + " ");

            if (asiento.getPasajero() != null) {
                if (asiento.getPasajero().getDestinoPasajero().equalsIgnoreCase("Luna")) {
                    System.out.print("LUN" + " ");
                }
                if (asiento.getPasajero().getDestinoPasajero().equalsIgnoreCase("Europa")) {
                    System.out.print("EUR" + " ");
                }
                if (asiento.getPasajero().getDestinoPasajero().equalsIgnoreCase("Titan")) {
                    System.out.print("TAN" + " ");
                }

            } else {
                System.out.print("TIC ");
            }

            if (i == 2 || i == 8 || i == 14 || i == 20) {
                System.out.print("|   ");
            }

            if (i == 5 || i == 11 || i == 17 || i == 23) {
                System.out.println("|");
            }
        }
        System.out.println("");
    }

    public void mostrarReporteReservaciones() {
        Scanner lol = new Scanner(System.in);
        int contOcupados=0,contDesocupados=0;
        Pasajero pasajero = new Pasajero();
        Asiento ob = new Asiento();
        System.out.printf("%-15s %-25s %-15s\n", " ", "Transportes Integalácticos de Cajeme, S.A.", " ");
        System.out.printf("%-25s %-25s %-15s\n", " ", "Lista de Reservaciones", " ");
        System.out.printf("%-40s", "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
        System.out.printf("%-20s %-10s %-20s %-10s %-20s %-25s %-15s\n", "No. del Asiento", "Nombre", "Identificacion", "Destino", "Clase del Asiento", "Ubicación del Asiento", "Costo del Boleto");
       for (Asiento asientoTemp: nave.ejecutivos)
       {
           pasajero = asientoTemp.getPasajero();
           if (asientoTemp.getPasajero()==null) 
           {
               contDesocupados++;
               System.out.printf("%-20s %-10s %-20s %-10s %-20s %-25s %-15s\n", "*Disponible*", "...", "...", "...", "...", "...", "*Disponible*");
           }
           if (asientoTemp.getPasajero()!=null) 
           {
               contOcupados++;
               System.out.printf("%-20s %-10s %-20s %-10s %-20s %-25s $%-15.0f\n",asientoTemp.getAsiento(),pasajero.getNombrePasajero(), 
                       pasajero.getIdentificacionPasajero(), pasajero.getDestinoPasajero(), asientoTemp.getClase(),asientoTemp.getUbicacion(),pasajero.obtenerCostoBoletoPasajero(asientoTemp.getClase()));
           }
       }
       for (Asiento asientoTemp: nave.economicos)
       {
           if (asientoTemp.getPasajero()==null) 
           {
               contDesocupados++;
               System.out.printf("%-20s %-10s %-20s %-10s %-20s %-25s %-15s\n", "*Disponible*", "...", "...", "...", "...", "...", "*Disponible*");
           }
           if (asientoTemp.getPasajero()!=null) 
           {
               contOcupados++;
               System.out.printf("%-20s %-10s %-20s %-10s %-20s %-25s $%-15.0f\n",asientoTemp.getAsiento(),pasajero.getNombrePasajero(), 
                       pasajero.getIdentificacionPasajero(), pasajero.getDestinoPasajero(), asientoTemp.getClase(),asientoTemp.getUbicacion(),pasajero.obtenerCostoBoletoPasajero(asientoTemp.getClase()));
           }
       }
        System.out.printf("%-40s", "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
        System.out.printf("%-20s %-2d", "Total de asientos ocupados: ", contOcupados);
        System.out.println("");
        System.out.printf("%-20s %-2d", "Total de asientos desocupados: ", contDesocupados);
        System.out.println("");
        System.out.printf("%-40s\n", "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("Presionar <Enter> para continuar");
        lol.nextLine();
        System.out.println("");
        System.out.println("¿Se desea continuar con el Reporte de Reservaciones, (S/N)?");
        String respuesta = lol.nextLine();
        if (!respuesta.equalsIgnoreCase("S") && !respuesta.equalsIgnoreCase("N") && !respuesta.equalsIgnoreCase("s") && !respuesta.equalsIgnoreCase("n")) {
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            System.out.println("||        ALGO SALIO MAL                   ||");
            System.out.println("||        LA RESPUESTA NO ES VÁLIDA        ||");
            System.out.println("|| FAVOR DE SELECCIONAR UNA OPCION VALIDA  ||");
            System.out.println("||        Presione <Enter> para continuar  ||");
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            lol.nextLine();
            lol.nextLine();
            System.out.println("Ingrese una respuesta valida (S/N)");
            respuesta = lol.nextLine();
        }
        if (respuesta.equalsIgnoreCase("S") || respuesta.equalsIgnoreCase("s")) {
            this.mostrarReporteReservaciones();
        }
        if (respuesta.equalsIgnoreCase("n") || respuesta.equalsIgnoreCase("N")) {
            mostrarMenuPrincipal();
        }
        System.out.printf("%-40s", "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
    }

    public void impError() {
        Scanner lol = new Scanner(System.in);
        System.out.printf("%-40s", "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
        System.out.printf("%-1s %-9s %-22s %-21s %-1s\n", "|", " ", "ERROR", " ", "|");
        System.out.printf("%-1s %-9s %-22s %-7s %-1s\n", "|", " ", "HAS SELECCIONADO UNA OPCION INVALIDA", " ", "|");
        System.out.printf("%-1s %-9s %-22s %-15s %-1s\n", "|", " ", "SELECCIONE UNA OPCION VALIDA", " ", "|");
        System.out.printf("%-1s %-9s %-22s %-12s %-1s\n", "|", " ", "Presione <Enter> para continuar", " ", "|");
        System.out.printf("%-40s", "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
        lol.nextLine();
        mostrarMenuPrincipal();
    }

    public void impErrorSubmenu() {
        Scanner lol = new Scanner(System.in);
        System.out.printf("%-40s", "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
        System.out.printf("%-1s %-9s %-22s %-21s %-1s\n", "|", " ", "ERROR", " ", "|");
        System.out.printf("%-1s %-9s %-22s %-7s %-1s\n", "|", " ", "HAS SELECCIONADO UNA OPCION INVALIDA", " ", "|");
        System.out.printf("%-1s %-9s %-22s %-15s %-1s\n", "|", " ", "SELECCIONE UNA OPCION VALIDA", " ", "|");
        System.out.printf("%-1s %-9s %-22s %-12s %-1s\n", "|", " ", "Presione <Enter> para continuar", " ", "|");
        System.out.printf("%-40s", "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
        lol.nextLine();
        this.mostrarSubmenuConsultaReservaciones();
    }

}
